A sample artifact wrapped in a single folder.
