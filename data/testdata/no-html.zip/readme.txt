A sample archive that carries no page.
